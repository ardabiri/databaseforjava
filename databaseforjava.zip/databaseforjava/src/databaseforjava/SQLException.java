package databaseforjava;

public class SQLException extends Exception {
	public SQLException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
