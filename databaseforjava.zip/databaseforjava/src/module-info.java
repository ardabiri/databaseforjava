/**
 * 
 */
/**
 * 
 */
module databaseforjava {
	requires java.sql;
}